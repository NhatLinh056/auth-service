# Auth Service Client SDK (`auth-service-client`)

Bộ thư viện Node.js độc lập (Zero Runtime Dependencies) giúp tích hợp tính năng đăng nhập tập trung và xác minh bảo vệ API bằng **Auth Service**.

---

## 1. Cài đặt

Gói SDK được phân phối dưới dạng file tarball chuẩn (`.tgz`):

```bash
# Trong thư mục dự án của bạn (cài express, dotenv và SDK):
npm install express dotenv /path/to/auth-service-client-1.0.0.tgz

# Hoặc tham chiếu file cục bộ trong package.json:
# "auth-service-client": "file:../auth-client/auth-service-client-1.0.0.tgz"
```

---

## 2. Chuẩn bị thông tin trên Developer Console

1. Truy cập Developer Console của Auth Service (`http://localhost:3000`).
2. Tạo Application mới và lấy cặp khóa dịch vụ:
   - `AppID`: Định danh ứng dụng (ví dụ `app_1234567890abcdef12345678`).
   - `AppToken`: Khóa bí mật backend (ví dụ `apt_1234567890abcdef...`).
3. Khai báo **Allowed Redirect URIs**:
   - Thêm chính xác URL callback của backend ứng dụng, ví dụ: `http://localhost:4000/auth/callback`.
4. Cấu hình biến môi trường ở backend (tuyệt đối không đưa ra frontend):
   ```env
   AUTH_SERVICE_URL=http://localhost:3000
   APP_ID=app_1234567890abcdef12345678
   APP_TOKEN=apt_1234567890abcdef...
   ```

---

## 3. Hướng dẫn Sử dụng

### 3.1. Dành cho Express.js (Express Adapter — Khuyên dùng)

Chỉ cần cấu hình một lần, gắn route đăng nhập/callback qua adapter và sử dụng một middleware duy nhất để bảo vệ API:

```typescript
import 'dotenv/config';
import express from 'express';
import { createAuthClient, createExpressAuthAdapter } from 'auth-service-client';

const app = express();

// 1. Cấu hình Auth Service một lần duy nhất
export const authClient = createAuthClient({
  authServiceUrl: process.env.AUTH_SERVICE_URL!,
  appId: process.env.APP_ID!,
  appToken: process.env.APP_TOKEN!,
});

// 2. Tạo Express Adapter: tự động quản lý phiên PKCE/state an toàn qua cookie HttpOnly
export const authAdapter = createExpressAuthAdapter(authClient, {
  redirectUri: process.env.REDIRECT_URI || 'http://localhost:3001/auth/callback',
  successRedirect: '/profile', // Điều hướng sau khi đăng nhập thành công
});

// 3. Gắn toàn bộ route đăng nhập Google/Facebook (/auth/login/google, /auth/login/facebook) và callback (/auth/callback)
app.use(authAdapter.router);
// Hoặc mount với prefix tùy chọn: authAdapter.mount(app, '/auth');

// 4. Trang profile cá nhân được bảo vệ (sau khi đăng nhập thành công sẽ chuyển hướng về đây)
app.get('/profile', authAdapter.requireAuth, (req, res) => {
  res.json({
    message: 'Đăng nhập thành công!',
    user: req.user,
  });
});

// 5. Bảo vệ API bằng một middleware duy nhất
app.get('/api/protected', authAdapter.requireAuth, (req, res) => {
  res.json({
    message: 'Xác thực thành công!',
    user: req.user,
  });
});
```

Giao diện HTML client hiển thị 2 nút chuyển hướng:
```html
<a href="/auth/login/google" class="btn btn-google">Đăng nhập bằng Google</a>
<a href="/auth/login/facebook" class="btn btn-facebook">Đăng nhập bằng Facebook</a>
```

---

### 3.2. Dành cho Framework khác hoặc Tùy biến Session (Core Framework-Neutral SDK)

#### 3.2.1. Khởi tạo Client

```typescript
import { createAuthClient } from 'auth-service-client';

export const auth = createAuthClient({
  authServiceUrl: process.env.AUTH_SERVICE_URL!,
  appId: process.env.APP_ID!,
  appToken: process.env.APP_TOKEN!,
  timeoutMs: 5000, // Timeout xác thực trực tuyến (mặc định 5s)
});
```

---

#### 3.2.2. Bắt đầu Đăng nhập (`beginLogin`)

Hàm `beginLogin` tạo cặp PKCE S256 (`verifier` + `codeChallenge`) và `state` chống CSRF. Hỗ trợ 2 hình thức:

#### Cách 1: Đăng nhập trực tiếp theo Provider (Google / Facebook) — Khuyên dùng
Ứng dụng khách hiển thị 2 nút riêng biệt "Đăng nhập bằng Google" và "Đăng nhập bằng Facebook":

```typescript
// Trong route xử lý GET /auth/login/google hoặc GET /auth/login/facebook:
const redirectUri = 'http://localhost:4000/auth/callback';

// Truyền options.provider ('google' | 'facebook') để điều hướng thẳng qua OAuth Broker:
const { authorizeUrl, transaction } = await auth.beginLogin(redirectUri, { provider: 'google' });

// BẮT BUỘC: Lưu transaction vào session cookie (HttpOnly) của trình duyệt
req.session.loginTransaction = transaction;

// Chuyển hướng người dùng thẳng tới Google/Facebook (không qua trang đăng nhập Auth Service)
res.redirect(authorizeUrl);
```

#### Cách 2: Đăng nhập tập trung (Centralized Login Flow)
Nếu muốn chuyển người dùng tới giao diện đăng nhập tập trung do Auth Service hiển thị:

```typescript
const { authorizeUrl, transaction } = await auth.beginLogin(redirectUri);
req.session.loginTransaction = transaction;
res.redirect(authorizeUrl);
```

> **Lưu ý bảo mật:** `transaction` gồm `state`, `verifier`, `redirectUri` và `createdAt`. Phải lưu gắn với phiên trình duyệt, không lưu trong biến toàn cục để tránh race-condition giữa nhiều người dùng. Mã authorization code trả về sau khi đăng nhập có thời hạn hiệu lực **60 giây** (`TTL 60s`).

---

### 3.3. Xử lý Callback & Đổi Code (`completeLogin`)

Tại endpoint callback đã đăng ký (`GET /auth/callback`):

```typescript
// Trong route xử lý GET /auth/callback:
const { code, state } = req.query;
const transaction = req.session.loginTransaction;

if (!transaction) {
  return res.status(400).json({ error: 'Không tìm thấy phiên đăng nhập' });
}

// Xóa transaction ngay lập tức (chống dùng lại mã)
delete req.session.loginTransaction;

// Đổi mã code lấy JWT Access Token và thông tin User
const { accessToken, user } = await auth.completeLogin({
  code: String(code),
  state: String(state),
  transaction,
});

// Lưu thông tin người dùng vào phiên ứng dụng
req.session.user = user;
req.session.accessToken = accessToken;

res.redirect('/dashboard');
```

---

### 3.4. Xác minh Token & Bảo vệ API (`verifyUser`)

Dùng để tạo Middleware / Guard bảo vệ các endpoint API nội bộ của bạn:

```typescript
// Middleware kiểm tra token trong Express / Node HTTP
async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Yêu cầu Bearer token' });
  }

  const token = authHeader.substring(7);

  try {
    // Xác thực trực tuyến với Auth Service
    const userProfile = await auth.verifyUser(token);
    req.user = userProfile;
    next();
  } catch (err) {
    // Fail closed: Từ chối nếu token sai, hết hạn, bị thu hồi hoặc sai App
    return res.status(401).json({ error: 'Token không hợp lệ hoặc đã hết hạn' });
  }
}

// Áp dụng middleware:
app.get('/api/orders', requireAuth, (req, res) => {
  res.json({ message: 'Danh sách đơn hàng', user: req.user });
});
```

---

### 3.5. Lấy danh sách Provider khả dụng (`getProviders`)

```typescript
const providers = await auth.getProviders();
// Trả về: [{ provider: 'google', name: 'Google', enabled: true }, ...]
```

---

## 4. Xử lý Lỗi & Fail-Closed

SDK cung cấp các lớp lỗi đặc thù:
- `AuthClientConfigError`: Sai hoặc thiếu cấu hình khi khởi tạo (`authServiceUrl`, `appId`, `appToken`).
- `AuthClientSecurityError`: Sai lệch `state` (nghi ngờ tấn công CSRF), thiếu mã code, hoặc phiên transaction quá 10 phút.
- `AuthClientHttpError`: Lỗi HTTP từ Auth Service (kèm `statusCode` và `responseBody`).
- `AuthClientVerificationError`: Xác thực token thất bại (token sai app, token `platform`, token hết hạn/thu hồi, hoặc Auth Service timeout/unreachable).

---

## 5. Giới hạn & Phạm vi Hỗ trợ

- **Backend-Only:** Chỉ dùng trong môi trường Node.js 18+ phía máy chủ (Next.js server routes/actions, NestJS, Express, Fastify). Không import vào code chạy trực tiếp trên browser hoặc ứng dụng mobile.
- **Xác thực trực tuyến:** Mọi thao tác xác minh token gọi trực tiếp về Auth Service để đảm bảo cập nhật trạng thái thu hồi phiên tức thì (R-02 revocation policy). Không hỗ trợ decode JWT offline mà bỏ qua xác minh.
